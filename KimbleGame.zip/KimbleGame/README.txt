/**************
***********
******
****
***
**
*/
GameDev@ConsoleOnlyText3DGraphicsComing
This is a Kimble game console application
Information about the game can be find at https://en.wikipedia.org/wiki/Kimble_(board_game)
The game can be further developed using a 3D libraries such as the OpenGL, Vulkan, and Ogre3D.
The code does not need any comments as it is very readable, self-explanatory, the code formatting and the naming of variables are very good.
The Single responsibility principle and open/close principle were taken into account 
(i.e. Multiple classes each with a single responsibility and are open for extension but closed for modification).
